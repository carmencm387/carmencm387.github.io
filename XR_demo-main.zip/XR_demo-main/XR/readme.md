


## EJEMPLOS REALIDAD AUMENTADA 


### Caso 1 - Uso de  **ARJS Studio** (https://ar-js-org.github.io/studio/) 
   Carpeta: [ar](https://github.com/mgea/mgea.github.io/tree/master/XR/ar) 

  (una sóla marca, asociar contenido imagen) 
  

### Caso 2 - Uso de  **ARJS Studio** con modelos 3D (https://ar-js-org.github.io/studio/) 

   Carpeta: [ar3D](https://github.com/mgea/mgea.github.io/tree/master/XR/ar3D) 

(una  marca, asociar contenido 3D con formato gltf) 
  
    

### Caso 3 - Uso de  **ARJS** con múltiples marcas 

   Carpeta: [webvr](https://github.com/mgea/mgea.github.io/tree/master/XR/webvr) 

Herramienta para crear códigos QR: https://www.qrcode-monkey.com/es/ 
 
 Updated 17/05/2022
