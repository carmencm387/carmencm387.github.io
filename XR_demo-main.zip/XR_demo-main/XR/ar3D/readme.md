
#### Creación de contenido 3D (en formato glTF) y asociado a marca 

Herramientas a utilizar: 

* **ARJS Studio** https://ar-js-org.github.io/studio/
* Creación de modelo 3D con **threejs editor** https://threejs.org/editor/  para exportar como glTF

Finalmente se sube contenido a github (repositorio Web) 



![Marca](default-marker.png) 

![Link](qr-codeEco.png)


Updated: 17/05/2022
