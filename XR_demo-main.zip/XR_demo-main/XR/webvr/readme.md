
EJEMPLO **multiples marcas con AR.JS**


Cada marca activa un tipo distinto de contenido (ar.js permite añadir musica, animación, etc.)

![Marca](Dado_webvr.png)
![QR](qr-code-webvr.png)

