#### EJEMPLO ARJS STUDIO

Creación de RA con **ARJS Studio** (https://ar-js-org.github.io/studio/) 


Subir contenido a github (repositorio Web) 



![Marca](default-marker.png) 

![Link](qr-code.png)
