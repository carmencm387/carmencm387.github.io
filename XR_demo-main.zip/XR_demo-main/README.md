# XR_demo
CDNCAV - demo de creación de contenidos de RA con AR.JS


(una vez clonado este repositorio, renonmbrar a nombre_usuario.github.io) 

Contenido: 
- Ejemplo de AR.JS (con patrones) en webvr 
- Ejemplo de contenido realizado con ARJS Studio https://ar-js-org.github.io/studio/pages/marker/index.html  


update. abril 2022
